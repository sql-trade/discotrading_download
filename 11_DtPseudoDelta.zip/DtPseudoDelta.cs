using System;

#region NinjaScript caching mechanism auxiliary code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{

		private DtPseudoDelta[] _cacheDtPseudoDelta = null;


		public DtPseudoDelta DtPseudoDelta(
			DiscoTrading.Nt8.DtPseudoDelta.Enums.VisualMode visualizationMode,
			DiscoTrading.Nt8.DtPseudoDelta.Enums.BaseMetric baseMetric,
			bool cumulativeMode,
			bool resetOnSessionStart,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.DataTableAppearance dataTableAppearance,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.DeltaCandlestickChartAppearance deltaCandlestickChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.TotalVsDeltaBarChartAppearance totalVsDeltaBarChartAppearance
			)
		{
			return DtPseudoDelta(
				Input,

				visualizationMode,
				baseMetric,
				cumulativeMode,
				resetOnSessionStart,
				dataTableAppearance,
				deltaCandlestickChartAppearance,
				totalVsDeltaBarChartAppearance
				);
		}

		public DtPseudoDelta DtPseudoDelta(
			ISeries<double> input,

			DiscoTrading.Nt8.DtPseudoDelta.Enums.VisualMode visualizationMode,
			DiscoTrading.Nt8.DtPseudoDelta.Enums.BaseMetric baseMetric,
			bool cumulativeMode,
			bool resetOnSessionStart,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.DataTableAppearance dataTableAppearance,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.DeltaCandlestickChartAppearance deltaCandlestickChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.TotalVsDeltaBarChartAppearance totalVsDeltaBarChartAppearance
			)
		{
			if (_cacheDtPseudoDelta != null)
				for (int idx = 0; idx < _cacheDtPseudoDelta.Length; idx++)
				{
					var cachedPseudoDelta = _cacheDtPseudoDelta[idx];
					if (
						cachedPseudoDelta.EqualsInput(input)
						&& cachedPseudoDelta.VisualizationMode == visualizationMode
						&& cachedPseudoDelta.BaseMetricProperty == baseMetric
						&& cachedPseudoDelta.CumulativeMode == cumulativeMode
						&& cachedPseudoDelta.ResetOnSessionStart == resetOnSessionStart
						&& Equals(cachedPseudoDelta.DataTableAppearanceProperties, dataTableAppearance)
						&& Equals(cachedPseudoDelta.DeltaCandlestickChartAppearanceProperties, deltaCandlestickChartAppearance)
						&& Equals(cachedPseudoDelta.TotalVsDeltaBarChartAppearanceProperties, totalVsDeltaBarChartAppearance)
					)
						return cachedPseudoDelta;

				}

			return CacheIndicator<DtPseudoDelta>(
				new DtPseudoDelta()
				{
					VisualizationMode = visualizationMode,
					BaseMetricProperty = baseMetric,
					CumulativeMode = cumulativeMode,
					ResetOnSessionStart = resetOnSessionStart,
					DataTableAppearanceProperties = dataTableAppearance,
					DeltaCandlestickChartAppearanceProperties = deltaCandlestickChartAppearance,
					TotalVsDeltaBarChartAppearanceProperties = totalVsDeltaBarChartAppearance
				},
				input,
				ref _cacheDtPseudoDelta
				);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.DtPseudoDelta DtPseudoDelta(
			DiscoTrading.Nt8.DtPseudoDelta.Enums.VisualMode visualizationMode,
			DiscoTrading.Nt8.DtPseudoDelta.Enums.BaseMetric baseMetric,
			bool cumulativeMode,
			bool resetOnSessionStart,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.DataTableAppearance dataTableAppearance,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.DeltaCandlestickChartAppearance deltaCandlestickChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.TotalVsDeltaBarChartAppearance totalVsDeltaBarChartAppearance
			)
		{
			return indicator.DtPseudoDelta(
				Input,

				visualizationMode,
				baseMetric,
				cumulativeMode,
				resetOnSessionStart,
				dataTableAppearance,
				deltaCandlestickChartAppearance,
				totalVsDeltaBarChartAppearance
			);
		}



		public Indicators.DtPseudoDelta DtPseudoDelta(
			ISeries<double> input,


			DiscoTrading.Nt8.DtPseudoDelta.Enums.VisualMode visualizationMode,
			DiscoTrading.Nt8.DtPseudoDelta.Enums.BaseMetric baseMetric,
			bool cumulativeMode,
			bool resetOnSessionStart,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.DataTableAppearance dataTableAppearance,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.DeltaCandlestickChartAppearance deltaCandlestickChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.TotalVsDeltaBarChartAppearance totalVsDeltaBarChartAppearance
			)
		{
			return indicator.DtPseudoDelta(
				input,

				visualizationMode,
				baseMetric,
				cumulativeMode,
				resetOnSessionStart,
				dataTableAppearance,
				deltaCandlestickChartAppearance,
				totalVsDeltaBarChartAppearance
			);
		}

	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{

		public Indicators.DtPseudoDelta DtPseudoDelta(
			DiscoTrading.Nt8.DtPseudoDelta.Enums.VisualMode visualizationMode,
			DiscoTrading.Nt8.DtPseudoDelta.Enums.BaseMetric baseMetric,
			bool cumulativeMode,
			bool resetOnSessionStart,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.DataTableAppearance dataTableAppearance,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.DeltaCandlestickChartAppearance deltaCandlestickChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.TotalVsDeltaBarChartAppearance totalVsDeltaBarChartAppearance
			)
		{
			return indicator.DtPseudoDelta(
				Input,

				visualizationMode,
				baseMetric,
				cumulativeMode,
				resetOnSessionStart,
				dataTableAppearance,
				deltaCandlestickChartAppearance,
				totalVsDeltaBarChartAppearance
			);
		}

		public Indicators.DtPseudoDelta DtPseudoDelta(
			ISeries<double> input,

			DiscoTrading.Nt8.DtPseudoDelta.Enums.VisualMode visualizationMode,
			DiscoTrading.Nt8.DtPseudoDelta.Enums.BaseMetric baseMetric,
			bool cumulativeMode,
			bool resetOnSessionStart,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.DataTableAppearance dataTableAppearance,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.DeltaCandlestickChartAppearance deltaCandlestickChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtPseudoDelta.TotalVsDeltaBarChartAppearance totalVsDeltaBarChartAppearance
			)
		{
			return indicator.DtPseudoDelta(
				input,

				visualizationMode,
				baseMetric,
				cumulativeMode,
				resetOnSessionStart,
				dataTableAppearance,
				deltaCandlestickChartAppearance,
				totalVsDeltaBarChartAppearance
			);
		}

	}
}

#endregion
