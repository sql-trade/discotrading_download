﻿using System;

#region DtFlowSpeed Auxuliary Code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{

		private DtFlowSpeed[] _cacheDtFlowSpeed = null;


		public DtFlowSpeed DtFlowSpeed(
			DiscoTrading.Nt8.DtFlowSpeed.Enums.DataSourceType dataSource,
			DiscoTrading.Nt8.DtFlowSpeed.Enums.DeltaMode deltaMode,

			int timeInterval,
			int period,
			double numOfStdDev,
			double numOfStdDevOfMeans,

			DiscoTrading.Nt8.DtFlowSpeed.Enums.FilterModes filterMode,
			long minSize,
			long maxSize,
			string rowOfSizes,
			DiscoTrading.Nt8.DtFlowSpeed.Enums.TradeSide filterBySide,

			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.AppearanceSettings appearanceSettings,
			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.PriceChartPaintingSettings priceChartPaintingSettings,
			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.AlertSettings highSpeedAlertSettings
			)
		{
			return DtFlowSpeed(
				Input,

				dataSource,
				deltaMode,

				timeInterval,
				period,
				numOfStdDev,
				numOfStdDevOfMeans,

				filterMode,
				minSize,
				maxSize,
				rowOfSizes,
				filterBySide,

				appearanceSettings,
				priceChartPaintingSettings,
				highSpeedAlertSettings
				);
		}

		public DtFlowSpeed DtFlowSpeed(
			ISeries<double> input,

			DiscoTrading.Nt8.DtFlowSpeed.Enums.DataSourceType dataSource,
			DiscoTrading.Nt8.DtFlowSpeed.Enums.DeltaMode deltaMode,

			int timeInterval,
			int period,
			double numOfStdDev,
			double numOfStdDevOfMeans,

			DiscoTrading.Nt8.DtFlowSpeed.Enums.FilterModes filterMode,
			long minSize,
			long maxSize,
			string rowOfSizes,
			DiscoTrading.Nt8.DtFlowSpeed.Enums.TradeSide filterBySide,

			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.AppearanceSettings appearanceSettings,
			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.PriceChartPaintingSettings priceChartPaintingSettings,
			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.AlertSettings highSpeedAlertSettings
			)
		{
			if (_cacheDtFlowSpeed != null)
				for (int idx = 0; idx < _cacheDtFlowSpeed.Length; idx++)
				{
					var cachedDtFlowSpeed = _cacheDtFlowSpeed[idx];
					if (
						cachedDtFlowSpeed.EqualsInput(input)
						&& cachedDtFlowSpeed.DataSource == dataSource
						&& cachedDtFlowSpeed.DeltaModeProperty == deltaMode

						&& cachedDtFlowSpeed.TimeInterval == timeInterval
						&& cachedDtFlowSpeed.Period == period
						&& Math.Abs(cachedDtFlowSpeed.NumOfStdDev - numOfStdDev) < 0.001
						&& Math.Abs(cachedDtFlowSpeed.NumOfStdDevOfMeans - numOfStdDevOfMeans) < 0.001

						&& cachedDtFlowSpeed.FilterMode == filterMode
						&& cachedDtFlowSpeed.MinSize == minSize
						&& cachedDtFlowSpeed.MaxSize == maxSize
						&& string.Equals(cachedDtFlowSpeed.RowOfSizes, rowOfSizes, StringComparison.InvariantCultureIgnoreCase)
						&& cachedDtFlowSpeed.FilterBySide == filterBySide

						&& Equals(cachedDtFlowSpeed.AppearanceProperties, appearanceSettings)
						&& Equals(cachedDtFlowSpeed.PriceChartPaintingProperties, priceChartPaintingSettings)
						&& Equals(cachedDtFlowSpeed.HighSpeedAlertProperties, highSpeedAlertSettings)
					)
						return cachedDtFlowSpeed;

				}

			return CacheIndicator<DtFlowSpeed>(
				new DtFlowSpeed()
				{
					DataSource = dataSource,
					DeltaModeProperty = deltaMode,

					TimeInterval = timeInterval,
					Period = period,
					NumOfStdDev = numOfStdDev,
					NumOfStdDevOfMeans = numOfStdDevOfMeans,
					FilterMode = filterMode,
					MinSize = minSize,
					MaxSize = maxSize,
					RowOfSizes = rowOfSizes,
					FilterBySide = filterBySide,

					AppearanceProperties = appearanceSettings,
					PriceChartPaintingProperties = priceChartPaintingSettings,
					HighSpeedAlertProperties = highSpeedAlertSettings
				},
				input,
				ref _cacheDtFlowSpeed
				);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.DtFlowSpeed DtFlowSpeed(
			DiscoTrading.Nt8.DtFlowSpeed.Enums.DataSourceType dataSource,
			DiscoTrading.Nt8.DtFlowSpeed.Enums.DeltaMode deltaMode,

			int timeInterval,
			int period,
			double numOfStdDev,
			double numOfStdDevOfMeans,

			DiscoTrading.Nt8.DtFlowSpeed.Enums.FilterModes filterMode,
			long minSize,
			long maxSize,
			string rowOfSizes,
			DiscoTrading.Nt8.DtFlowSpeed.Enums.TradeSide filterBySide,

			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.AppearanceSettings appearanceSettings,
			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.PriceChartPaintingSettings priceChartPaintingSettings,
			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.AlertSettings highSpeedAlertSettings
			)
		{
			return indicator.DtFlowSpeed(
				Input,

				dataSource,
				deltaMode,

				timeInterval,
				period,
				numOfStdDev,
				numOfStdDevOfMeans,

				filterMode,
				minSize,
				maxSize,
				rowOfSizes,
				filterBySide,

				appearanceSettings,
				priceChartPaintingSettings,
				highSpeedAlertSettings
			);
		}
		
		public Indicators.DtFlowSpeed DtFlowSpeed(
			ISeries<double> input,

			DiscoTrading.Nt8.DtFlowSpeed.Enums.DataSourceType dataSource,
			DiscoTrading.Nt8.DtFlowSpeed.Enums.DeltaMode deltaMode,

			int timeInterval,
			int period,
			double numOfStdDev,
			double numOfStdDevOfMeans,

			DiscoTrading.Nt8.DtFlowSpeed.Enums.FilterModes filterMode,
			long minSize,
			long maxSize,
			string rowOfSizes,
			DiscoTrading.Nt8.DtFlowSpeed.Enums.TradeSide filterBySide,

			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.AppearanceSettings appearanceSettings,
			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.PriceChartPaintingSettings priceChartPaintingSettings,
			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.AlertSettings highSpeedAlertSettings
			)
		{
			return indicator.DtFlowSpeed(
				input,

				dataSource,
				deltaMode,

				timeInterval,
				period,
				numOfStdDev,
				numOfStdDevOfMeans,

				filterMode,
				minSize,
				maxSize,
				rowOfSizes,
				filterBySide,

				appearanceSettings,
				priceChartPaintingSettings,
				highSpeedAlertSettings
			);
		}

	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.DtFlowSpeed DtFlowSpeed(
			DiscoTrading.Nt8.DtFlowSpeed.Enums.DataSourceType dataSource,
			DiscoTrading.Nt8.DtFlowSpeed.Enums.DeltaMode deltaMode,

			int timeInterval,
			int period,
			double numOfStdDev,
			double numOfStdDevOfMeans,

			DiscoTrading.Nt8.DtFlowSpeed.Enums.FilterModes filterMode,
			long minSize,
			long maxSize,
			string rowOfSizes,
			DiscoTrading.Nt8.DtFlowSpeed.Enums.TradeSide filterBySide,

			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.AppearanceSettings appearanceSettings,
			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.PriceChartPaintingSettings priceChartPaintingSettings,
			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.AlertSettings highSpeedAlertSettings
			)
		{
			return indicator.DtFlowSpeed(
				Input,

				dataSource,
				deltaMode,

				timeInterval,
				period,
				numOfStdDev,
				numOfStdDevOfMeans,

				filterMode,
				minSize,
				maxSize,
				rowOfSizes,
				filterBySide,

				appearanceSettings,
				priceChartPaintingSettings,
				highSpeedAlertSettings
			);
		}

		public Indicators.DtFlowSpeed DtFlowSpeed(
			ISeries<double> input,

			DiscoTrading.Nt8.DtFlowSpeed.Enums.DataSourceType dataSource,
			DiscoTrading.Nt8.DtFlowSpeed.Enums.DeltaMode deltaMode,

			int timeInterval,
			int period,
			double numOfStdDev,
			double numOfStdDevOfMeans,

			DiscoTrading.Nt8.DtFlowSpeed.Enums.FilterModes filterMode,
			long minSize,
			long maxSize,
			string rowOfSizes,
			DiscoTrading.Nt8.DtFlowSpeed.Enums.TradeSide filterBySide,

			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.AppearanceSettings appearanceSettings,
			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.PriceChartPaintingSettings priceChartPaintingSettings,
			NinjaTrader.NinjaScript.Indicators.DtFlowSpeed.AlertSettings highSpeedAlertSettings
			)
		{
			return indicator.DtFlowSpeed(
				input,

				dataSource,
				deltaMode,

				timeInterval,
				period,
				numOfStdDev,
				numOfStdDevOfMeans,

				filterMode,
				minSize,
				maxSize,
				rowOfSizes,
				filterBySide,

				appearanceSettings,
				priceChartPaintingSettings,
				highSpeedAlertSettings
			);
		}

	}
}

#endregion