using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{

		private DtUniversalBands[] cacheDtUniversalBands = null;


		public DtUniversalBands DtUniversalBands(
			double bandMultiplier1, double bandMultiplier2, double bandMultiplier3, double bandMultiplier4, double bandMultiplier5, double bandMultiplier6,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BarRangeCalcMode bands_BarRangeCalcMode,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BandsPeriodTypes bands_PeriodType,
			DiscoTrading.Nt8.DtUniversalBands.Enums.StdDevCalcMode bands_StdDevCalcMode,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BandsTypes bands_Type,
			double bands_ValueAreaToleranceIntervalPct,
			DiscoTrading.Nt8.DtUniversalBands.Enums.ValueAreaType bands_ValueAreaType,

			DiscoTrading.Nt8.DtUniversalBands.Enums.BaselineCalcMethods baseline_CalculationMethod,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BaselinePeriodTypes baseline_PeriodType,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSource dataSourceBaseline,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSource dataSourceValueArea,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSourceForVWAP dataSourceVWAP,
			TimeSpan initialTime,
			int period_BandsRelated,
			int period_BaselineRelated,
			bool showBands)
		{
			return DtUniversalBands(Input, bandMultiplier1, bandMultiplier2, bandMultiplier3, bandMultiplier4, bandMultiplier5, bandMultiplier6, bands_BarRangeCalcMode, bands_PeriodType, bands_StdDevCalcMode, bands_Type, bands_ValueAreaToleranceIntervalPct, bands_ValueAreaType, baseline_CalculationMethod, baseline_PeriodType, dataSourceBaseline, dataSourceValueArea, dataSourceVWAP, initialTime, period_BandsRelated, period_BaselineRelated, showBands);
		}



		public DtUniversalBands DtUniversalBands(
			ISeries<double> input,

			double bandMultiplier1, double bandMultiplier2, double bandMultiplier3, double bandMultiplier4, double bandMultiplier5, double bandMultiplier6,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BarRangeCalcMode bands_BarRangeCalcMode,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BandsPeriodTypes bands_PeriodType,
			DiscoTrading.Nt8.DtUniversalBands.Enums.StdDevCalcMode bands_StdDevCalcMode,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BandsTypes bands_Type,
			double bands_ValueAreaToleranceIntervalPct,
			DiscoTrading.Nt8.DtUniversalBands.Enums.ValueAreaType bands_ValueAreaType,

			DiscoTrading.Nt8.DtUniversalBands.Enums.BaselineCalcMethods baseline_CalculationMethod,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BaselinePeriodTypes baseline_PeriodType,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSource dataSourceBaseline,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSource dataSourceValueArea,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSourceForVWAP dataSourceVWAP,
			TimeSpan initialTime,
			int period_BandsRelated,
			int period_BaselineRelated,
			bool showBands
			)
		{
			if (cacheDtUniversalBands != null)
				for (int idx = 0; idx < cacheDtUniversalBands.Length; idx++)
					if (Math.Abs(cacheDtUniversalBands[idx].BandMultiplier1 - bandMultiplier1) <= double.Epsilon && Math.Abs(cacheDtUniversalBands[idx].BandMultiplier2 - bandMultiplier2) <= double.Epsilon && Math.Abs(cacheDtUniversalBands[idx].BandMultiplier3 - bandMultiplier3) <= double.Epsilon && Math.Abs(cacheDtUniversalBands[idx].BandMultiplier4 - bandMultiplier4) <= double.Epsilon && Math.Abs(cacheDtUniversalBands[idx].BandMultiplier5 - bandMultiplier5) <= double.Epsilon && Math.Abs(cacheDtUniversalBands[idx].BandMultiplier6 - bandMultiplier6) <= double.Epsilon && cacheDtUniversalBands[idx].BandsBarRangeCalcMode == bands_BarRangeCalcMode && cacheDtUniversalBands[idx].BandsPeriodType == bands_PeriodType && cacheDtUniversalBands[idx].BandsStdDevCalcMode == bands_StdDevCalcMode && cacheDtUniversalBands[idx].BandsType == bands_Type && Math.Abs(cacheDtUniversalBands[idx].BandsValueAreaToleranceIntervalPct - bands_ValueAreaToleranceIntervalPct) <= double.Epsilon && cacheDtUniversalBands[idx].BandsValueAreaType == bands_ValueAreaType && cacheDtUniversalBands[idx].BaselineCalculationMethod == baseline_CalculationMethod && cacheDtUniversalBands[idx].BaselinePeriodType == baseline_PeriodType && cacheDtUniversalBands[idx].DataSourceBaseline == dataSourceBaseline && cacheDtUniversalBands[idx].DataSourceValueArea == dataSourceValueArea && cacheDtUniversalBands[idx].DataSourceVwap == dataSourceVWAP && cacheDtUniversalBands[idx].InitialTime == initialTime && cacheDtUniversalBands[idx].PeriodBandsRelated == period_BandsRelated && cacheDtUniversalBands[idx].PeriodBaselineRelated == period_BaselineRelated && cacheDtUniversalBands[idx].ShowBands == showBands && cacheDtUniversalBands[idx].EqualsInput(input))
						return cacheDtUniversalBands[idx];

			return CacheIndicator<DtUniversalBands>(
				new DtUniversalBands()
				{
					BandMultiplier1 = bandMultiplier1,
					BandMultiplier2 = bandMultiplier2,
					BandMultiplier3 = bandMultiplier3,
					BandMultiplier4 = bandMultiplier4,
					BandMultiplier5 = bandMultiplier5,
					BandMultiplier6 = bandMultiplier6,

					BandsBarRangeCalcMode = bands_BarRangeCalcMode,
					BandsPeriodType = bands_PeriodType,
					BandsStdDevCalcMode = bands_StdDevCalcMode,
					BandsType = bands_Type,
					BandsValueAreaToleranceIntervalPct = bands_ValueAreaToleranceIntervalPct,
					BandsValueAreaType = bands_ValueAreaType,

					BaselineCalculationMethod = baseline_CalculationMethod,
					BaselinePeriodType = baseline_PeriodType,
					DataSourceBaseline = dataSourceBaseline,
					DataSourceValueArea = dataSourceValueArea,
					DataSourceVwap = dataSourceVWAP,
					InitialTime = initialTime,
					PeriodBandsRelated = period_BandsRelated,
					PeriodBaselineRelated = period_BaselineRelated,
					ShowBands = showBands
				},
				input,
				ref cacheDtUniversalBands
				);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{

		public Indicators.DtUniversalBands DtUniversalBands(
			double bandMultiplier1, double bandMultiplier2, double bandMultiplier3, double bandMultiplier4, double bandMultiplier5, double bandMultiplier6,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BarRangeCalcMode bands_BarRangeCalcMode,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BandsPeriodTypes bands_PeriodType,
			DiscoTrading.Nt8.DtUniversalBands.Enums.StdDevCalcMode bands_StdDevCalcMode,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BandsTypes bands_Type,
			double bands_ValueAreaToleranceIntervalPct,
			DiscoTrading.Nt8.DtUniversalBands.Enums.ValueAreaType bands_ValueAreaType,

			DiscoTrading.Nt8.DtUniversalBands.Enums.BaselineCalcMethods baseline_CalculationMethod,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BaselinePeriodTypes baseline_PeriodType,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSource dataSourceBaseline,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSource dataSourceValueArea,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSourceForVWAP dataSourceVWAP,
			TimeSpan initialTime,
			int period_BandsRelated,
			int period_BaselineRelated,
			bool showBands
			)
		{
			return indicator.DtUniversalBands(Input, bandMultiplier1, bandMultiplier2, bandMultiplier3, bandMultiplier4, bandMultiplier5, bandMultiplier6, bands_BarRangeCalcMode, bands_PeriodType, bands_StdDevCalcMode, bands_Type, bands_ValueAreaToleranceIntervalPct, bands_ValueAreaType, baseline_CalculationMethod, baseline_PeriodType, dataSourceBaseline, dataSourceValueArea, dataSourceVWAP, initialTime, period_BandsRelated, period_BaselineRelated, showBands);
		}



		public Indicators.DtUniversalBands DtUniversalBands(
			ISeries<double> input,

			double bandMultiplier1, double bandMultiplier2, double bandMultiplier3, double bandMultiplier4, double bandMultiplier5, double bandMultiplier6,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BarRangeCalcMode bands_BarRangeCalcMode,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BandsPeriodTypes bands_PeriodType,
			DiscoTrading.Nt8.DtUniversalBands.Enums.StdDevCalcMode bands_StdDevCalcMode,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BandsTypes bands_Type,
			double bands_ValueAreaToleranceIntervalPct,
			DiscoTrading.Nt8.DtUniversalBands.Enums.ValueAreaType bands_ValueAreaType,

			DiscoTrading.Nt8.DtUniversalBands.Enums.BaselineCalcMethods baseline_CalculationMethod,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BaselinePeriodTypes baseline_PeriodType,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSource dataSourceBaseline,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSource dataSourceValueArea,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSourceForVWAP dataSourceVWAP,
			TimeSpan initialTime,
			int period_BandsRelated,
			int period_BaselineRelated,
			bool showBands
			)
		{
			return indicator.DtUniversalBands(input, bandMultiplier1, bandMultiplier2, bandMultiplier3, bandMultiplier4, bandMultiplier5, bandMultiplier6, bands_BarRangeCalcMode, bands_PeriodType, bands_StdDevCalcMode, bands_Type, bands_ValueAreaToleranceIntervalPct, bands_ValueAreaType, baseline_CalculationMethod, baseline_PeriodType, dataSourceBaseline, dataSourceValueArea, dataSourceVWAP, initialTime, period_BandsRelated, period_BaselineRelated, showBands);
		}

	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{

		public Indicators.DtUniversalBands DtUniversalBands(
			double bandMultiplier1, double bandMultiplier2, double bandMultiplier3, double bandMultiplier4, double bandMultiplier5, double bandMultiplier6,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BarRangeCalcMode bands_BarRangeCalcMode,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BandsPeriodTypes bands_PeriodType,
			DiscoTrading.Nt8.DtUniversalBands.Enums.StdDevCalcMode bands_StdDevCalcMode,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BandsTypes bands_Type,
			double bands_ValueAreaToleranceIntervalPct,
			DiscoTrading.Nt8.DtUniversalBands.Enums.ValueAreaType bands_ValueAreaType,

			DiscoTrading.Nt8.DtUniversalBands.Enums.BaselineCalcMethods baseline_CalculationMethod,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BaselinePeriodTypes baseline_PeriodType,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSource dataSourceBaseline,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSource dataSourceValueArea,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSourceForVWAP dataSourceVWAP,
			TimeSpan initialTime,
			int period_BandsRelated,
			int period_BaselineRelated,
			bool showBands
			)
		{
			return indicator.DtUniversalBands(Input, bandMultiplier1, bandMultiplier2, bandMultiplier3, bandMultiplier4, bandMultiplier5, bandMultiplier6, bands_BarRangeCalcMode, bands_PeriodType, bands_StdDevCalcMode, bands_Type, bands_ValueAreaToleranceIntervalPct, bands_ValueAreaType, baseline_CalculationMethod, baseline_PeriodType, dataSourceBaseline, dataSourceValueArea, dataSourceVWAP, initialTime, period_BandsRelated, period_BaselineRelated, showBands);
		}



		public Indicators.DtUniversalBands DtUniversalBands(
			ISeries<double> input,

			double bandMultiplier1, double bandMultiplier2, double bandMultiplier3, double bandMultiplier4, double bandMultiplier5, double bandMultiplier6,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BarRangeCalcMode bands_BarRangeCalcMode,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BandsPeriodTypes bands_PeriodType,
			DiscoTrading.Nt8.DtUniversalBands.Enums.StdDevCalcMode bands_StdDevCalcMode,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BandsTypes bands_Type,
			double bands_ValueAreaToleranceIntervalPct,
			DiscoTrading.Nt8.DtUniversalBands.Enums.ValueAreaType bands_ValueAreaType,

			DiscoTrading.Nt8.DtUniversalBands.Enums.BaselineCalcMethods baseline_CalculationMethod,
			DiscoTrading.Nt8.DtUniversalBands.Enums.BaselinePeriodTypes baseline_PeriodType,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSource dataSourceBaseline,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSource dataSourceValueArea,
			DiscoTrading.Nt8.DtUniversalBands.Enums.DataSourceForVWAP dataSourceVWAP,
			TimeSpan initialTime,
			int period_BandsRelated,
			int period_BaselineRelated,
			bool showBands
			)
		{
			return indicator.DtUniversalBands(input, bandMultiplier1, bandMultiplier2, bandMultiplier3, bandMultiplier4, bandMultiplier5, bandMultiplier6, bands_BarRangeCalcMode, bands_PeriodType, bands_StdDevCalcMode, bands_Type, bands_ValueAreaToleranceIntervalPct, bands_ValueAreaType, baseline_CalculationMethod, baseline_PeriodType, dataSourceBaseline, dataSourceValueArea, dataSourceVWAP, initialTime, period_BandsRelated, period_BaselineRelated, showBands);
		}

	}
}

#endregion
