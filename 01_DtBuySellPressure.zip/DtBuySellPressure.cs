﻿using System;

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{

		private DtBuySellPressure[] _cacheDtBuySellPressure = null;


		public DtBuySellPressure DtBuySellPressure(
			DiscoTrading.Nt8.DtBuySellPressure.Enums.DataSourceType dataSource,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.VisualMode visualizationMode,
			DiscoTrading.Nt8.DtBuySellPressure.Enums.BaseMetric baseMetric,
			DiscoTrading.Nt8.DtBuySellPressure.Enums.DeltaMode deltaMode,
			bool cumulativeMode,
			bool resetOnSessionStart,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.BracketMode bracketMode,
			long bracketThresholdVolume,
			int bracketBars,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.FilterModes filterMode,
			long minSize,
			long maxSize,
			string rowOfSizes,

			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DataTableAppearance dataTableAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaCandlestickChartAppearance deltaCandlestickChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.TotalVsDeltaBarChartAppearance totalVsDeltaBarChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaMarksAppearance deltaMarksAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.PocMarksAppearance pocMarksAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaConvDivMarksSettings deltaConvDivMarksSettings
			)
		{
			return DtBuySellPressure(
				Input,

				dataSource,

				visualizationMode,
				baseMetric,
				deltaMode,
				cumulativeMode,
				resetOnSessionStart,
				bracketMode,
				bracketThresholdVolume,
				bracketBars,

				filterMode,
				minSize,
				maxSize,
				rowOfSizes,

				dataTableAppearance,
				deltaCandlestickChartAppearance,
				totalVsDeltaBarChartAppearance,
				deltaMarksAppearance,
				pocMarksAppearance,
				deltaConvDivMarksSettings
				);
		}

		public DtBuySellPressure DtBuySellPressure(
			ISeries<double> input,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.DataSourceType dataSource,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.VisualMode visualizationMode,
			DiscoTrading.Nt8.DtBuySellPressure.Enums.BaseMetric baseMetric,
			DiscoTrading.Nt8.DtBuySellPressure.Enums.DeltaMode deltaMode,
			bool cumulativeMode,
			bool resetOnSessionStart,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.BracketMode bracketMode,
			long bracketThresholdVolume,
			int bracketBars,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.FilterModes filterMode,
			long minSize,
			long maxSize,
			string rowOfSizes,

			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DataTableAppearance dataTableAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaCandlestickChartAppearance deltaCandlestickChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.TotalVsDeltaBarChartAppearance totalVsDeltaBarChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaMarksAppearance deltaMarksAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.PocMarksAppearance pocMarksAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaConvDivMarksSettings deltaConvDivMarksSettings
			)
		{
			if (_cacheDtBuySellPressure != null)
				for (int idx = 0; idx < _cacheDtBuySellPressure.Length; idx++)
				{
					var cachedBsp = _cacheDtBuySellPressure[idx];
					if (
						cachedBsp.EqualsInput(input)
						&& cachedBsp.DataSource == dataSource
						&& cachedBsp.VisualizationMode == visualizationMode
						&& cachedBsp.BaseMetricProperty == baseMetric
						&& cachedBsp.DeltaModeProperty == deltaMode
						&& cachedBsp.CumulativeMode == cumulativeMode
						&& cachedBsp.ResetOnSessionStart == resetOnSessionStart
						&& cachedBsp.BracketModeProperty == bracketMode
						&& cachedBsp.BracketThresholdVolume == bracketThresholdVolume
						&& cachedBsp.BracketBars == bracketBars
						&& cachedBsp.FilterMode == filterMode
						&& cachedBsp.MinSize == minSize
						&& cachedBsp.MaxSize == maxSize
						&& string.Equals(cachedBsp.RowOfSizes, rowOfSizes, StringComparison.InvariantCultureIgnoreCase)

						&& Equals(cachedBsp.DataTableAppearanceProperties, dataTableAppearance)
						&& Equals(cachedBsp.DeltaCandlestickChartAppearanceProperties, deltaCandlestickChartAppearance)
						&& Equals(cachedBsp.TotalVsDeltaBarChartAppearanceProperties, totalVsDeltaBarChartAppearance)
						&& Equals(cachedBsp.DeltaMarksAppearanceProperties, deltaMarksAppearance)
						&& Equals(cachedBsp.PocMarksAppearanceProperties, pocMarksAppearance)
						&& Equals(cachedBsp.DeltaConvDivMarksProperties, deltaConvDivMarksSettings)
					)
						return cachedBsp;

				}

			return CacheIndicator<DtBuySellPressure>(
				new DtBuySellPressure()
				{
					DataSource = dataSource,

					VisualizationMode = visualizationMode,
					BaseMetricProperty = baseMetric,
					DeltaModeProperty = deltaMode,
					CumulativeMode = cumulativeMode,
					ResetOnSessionStart = resetOnSessionStart,
					BracketModeProperty = bracketMode,
					BracketThresholdVolume = bracketThresholdVolume,
					BracketBars = bracketBars,
					FilterMode = filterMode,
					MinSize = minSize,
					MaxSize = maxSize,
					RowOfSizes = rowOfSizes,

					DataTableAppearanceProperties = dataTableAppearance,
					DeltaCandlestickChartAppearanceProperties = deltaCandlestickChartAppearance,
					TotalVsDeltaBarChartAppearanceProperties = totalVsDeltaBarChartAppearance,
					DeltaMarksAppearanceProperties = deltaMarksAppearance,
					PocMarksAppearanceProperties = pocMarksAppearance,
					DeltaConvDivMarksProperties = deltaConvDivMarksSettings
				},
				input,
				ref _cacheDtBuySellPressure
				);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{

		public Indicators.DtBuySellPressure DtBuySellPressure(
			DiscoTrading.Nt8.DtBuySellPressure.Enums.DataSourceType dataSource,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.VisualMode visualizationMode,
			DiscoTrading.Nt8.DtBuySellPressure.Enums.BaseMetric baseMetric,
			DiscoTrading.Nt8.DtBuySellPressure.Enums.DeltaMode deltaMode,
			bool cumulativeMode,
			bool resetOnSessionStart,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.BracketMode bracketMode,
			long bracketThresholdVolume,
			int bracketBars,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.FilterModes filterMode,
			long minSize,
			long maxSize,
			string rowOfSizes,

			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DataTableAppearance dataTableAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaCandlestickChartAppearance deltaCandlestickChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.TotalVsDeltaBarChartAppearance totalVsDeltaBarChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaMarksAppearance deltaMarksAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.PocMarksAppearance pocMarksAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaConvDivMarksSettings deltaConvDivMarksSettings
			)
		{
			return indicator.DtBuySellPressure(
				Input,

				dataSource,

				visualizationMode,
				baseMetric,
				deltaMode,
				cumulativeMode,
				resetOnSessionStart,
				bracketMode,
				bracketThresholdVolume,
				bracketBars,
				filterMode,
				minSize,
				maxSize,
				rowOfSizes,

				dataTableAppearance,
				deltaCandlestickChartAppearance,
				totalVsDeltaBarChartAppearance,
				deltaMarksAppearance,
				pocMarksAppearance,
				deltaConvDivMarksSettings
			);
		}



		public Indicators.DtBuySellPressure DtBuySellPressure(
			ISeries<double> input,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.DataSourceType dataSource,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.VisualMode visualizationMode,
			DiscoTrading.Nt8.DtBuySellPressure.Enums.BaseMetric baseMetric,
			DiscoTrading.Nt8.DtBuySellPressure.Enums.DeltaMode deltaMode,
			bool cumulativeMode,
			bool resetOnSessionStart,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.BracketMode bracketMode,
			long bracketThresholdVolume,
			int bracketBars,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.FilterModes filterMode,
			long minSize,
			long maxSize,
			string rowOfSizes,

			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DataTableAppearance dataTableAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaCandlestickChartAppearance deltaCandlestickChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.TotalVsDeltaBarChartAppearance totalVsDeltaBarChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaMarksAppearance deltaMarksAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.PocMarksAppearance pocMarksAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaConvDivMarksSettings deltaConvDivMarksSettings
			)
		{
			return indicator.DtBuySellPressure(
				input,

				dataSource,

				visualizationMode,
				baseMetric,
				deltaMode,
				cumulativeMode,
				resetOnSessionStart,
				bracketMode,
				bracketThresholdVolume,
				bracketBars,

				filterMode,
				minSize,
				maxSize,
				rowOfSizes,

				dataTableAppearance,
				deltaCandlestickChartAppearance,
				totalVsDeltaBarChartAppearance,
				deltaMarksAppearance,
				pocMarksAppearance,
				deltaConvDivMarksSettings
			);
		}

	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{

		public Indicators.DtBuySellPressure DtBuySellPressure(
			DiscoTrading.Nt8.DtBuySellPressure.Enums.DataSourceType dataSource,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.VisualMode visualizationMode,
			DiscoTrading.Nt8.DtBuySellPressure.Enums.BaseMetric baseMetric,
			DiscoTrading.Nt8.DtBuySellPressure.Enums.DeltaMode deltaMode,
			bool cumulativeMode,
			bool resetOnSessionStart,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.BracketMode bracketMode,
			long bracketThresholdVolume,
			int bracketBars,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.FilterModes filterMode,
			long minSize,
			long maxSize,
			string rowOfSizes,

			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DataTableAppearance dataTableAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaCandlestickChartAppearance deltaCandlestickChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.TotalVsDeltaBarChartAppearance totalVsDeltaBarChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaMarksAppearance deltaMarksAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.PocMarksAppearance pocMarksAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaConvDivMarksSettings deltaConvDivMarksSettings
			)
		{
			return indicator.DtBuySellPressure(
				Input,

				dataSource,

				visualizationMode,
				baseMetric,
				deltaMode,
				cumulativeMode,
				resetOnSessionStart,
				bracketMode,
				bracketThresholdVolume,
				bracketBars,
				filterMode,
				minSize,
				maxSize,
				rowOfSizes,

				dataTableAppearance,
				deltaCandlestickChartAppearance,
				totalVsDeltaBarChartAppearance,
				deltaMarksAppearance,
				pocMarksAppearance,
				deltaConvDivMarksSettings
			);
		}

		public Indicators.DtBuySellPressure DtBuySellPressure(
			ISeries<double> input,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.DataSourceType dataSource,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.VisualMode visualizationMode,
			DiscoTrading.Nt8.DtBuySellPressure.Enums.BaseMetric baseMetric,
			DiscoTrading.Nt8.DtBuySellPressure.Enums.DeltaMode deltaMode,
			bool cumulativeMode,
			bool resetOnSessionStart,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.BracketMode bracketMode,
			long bracketThresholdVolume,
			int bracketBars,

			DiscoTrading.Nt8.DtBuySellPressure.Enums.FilterModes filterMode,
			long minSize,
			long maxSize,
			string rowOfSizes,

			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DataTableAppearance dataTableAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaCandlestickChartAppearance deltaCandlestickChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.TotalVsDeltaBarChartAppearance totalVsDeltaBarChartAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaMarksAppearance deltaMarksAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.PocMarksAppearance pocMarksAppearance,
			NinjaTrader.NinjaScript.Indicators.DtBuySellPressure.DeltaConvDivMarksSettings deltaConvDivMarksSettings
			)
		{
			return indicator.DtBuySellPressure(
				input,

				dataSource,

				visualizationMode,
				baseMetric,
				deltaMode,
				cumulativeMode,
				resetOnSessionStart,
				bracketMode,
				bracketThresholdVolume,
				bracketBars,
				filterMode,
				minSize,
				maxSize,
				rowOfSizes,

				dataTableAppearance,
				deltaCandlestickChartAppearance,
				totalVsDeltaBarChartAppearance,
				deltaMarksAppearance,
				pocMarksAppearance,
				deltaConvDivMarksSettings
			);
		}

	}
}

#endregion
